package com.example.hueappla;

public interface menu_fragmentListener {
    void OnGroupsButtonClicked();
    void OnLampsButtonClicked();
    void OnAllLampsButtonClicked();

}
